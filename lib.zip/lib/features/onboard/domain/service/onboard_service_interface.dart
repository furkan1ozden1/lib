import 'package:get/get.dart';

abstract class OnboardServiceInterface {
  Future<Response> getOnBoardingList();
}